/**
 * Memory.java
 * 05.02.2019
 */
package oopArrayAufg;

import java.util.Random;

/**
 * @author stk
 *
 *
 *         Kurzbeschreibung: Die Klasse realisiert ein Memory Spielfeld
 */
/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class Memory
{
	private char[][] acVorlage;  // Zuf�llige Belegung der Felder mit Paaren
	private char[][] acMaske;    // Bereits gefundene Paare bzw. aufgedeckte Felder
	private int iAnzPaare;       // gesamte Anzahl Paare bei geg. Spielfeld
	private int iAnzRichtig = 0; // bereits richtig gefundene Paare
	private int iAnzSchritte = 0;// Anzahl der durchgef�hrten Versuche
	private int iZustand = 0;    // Variable f�r Zustandssteuerung des Spielablaufs
	private Koordinaten koordZustand1 = new Koordinaten(); // welches Feld wurde als 1. aufgedeckt
	private Koordinaten koordZustand2 = new Koordinaten(); // welches Feld wurde als 2. aufgedeckt

	/**
	 *        Der Konstruktor bereitet das "Spielfeld" vor:
	 *        Abh�ngig von der Anzahl der gesuchten Paare, wird ein 2-dim Array f�r die
	 *        gesuchten Paare erzeugt: acVorlage (siehe Attribute)
	 *        und eine 2-dim Array f�r die bereits aufgedeckten Paare: acMaske (siehe Attribute)
	 * @param iAnzPaare
	 *        Anzahl der im Memory vorhandenen Paare. Der Parameter darf nur solche Werte annehmen,
	 *        dass sich daraus ein Quadrat bilden l�sst: 4, 18, 32, ... 
	 */
	public Memory(int iAnzPaare)
	{
		// lokale Variablen anlegen
		
		// iAnzPaare in Attribut speichern
		
		// Seitenl�nge des quadratischen Spielfeldes bestimmen

		// 2-dim. Array f�r die gesuchten Paare erzeugen: acVorlage (siehe Attribute)

		// 2-dim. Array f�r die bereits aufgedeckten Paare erzeugen: acMaske (siehe Attribute)

		
		// acMaske mit '#' f�llen -> Startzustand, alle Felder sind "abgedeckt"
		// acVorlage mit zuf�lligen Paaren auf zuf�lligen Pl�tzen belegen
		//           F�r die Paare k�nnen Zeichen aus dem Unicode Bereich ab dem '$' Zeichen
		//           nacheinander verwendet werden (oder andere nach Wahl)
		// Die Koordinaten f�r die Platzierung m�ssen zuf�llig in dem entsprechenden Wertebereich
		// erzeugt werden, und es muss gepr�ft werden, ob der zuf�llig ermittelte Platz nicht 
		// schon belegt ist, sonst m�ssen neue Koordinaten gew�hlt werden.


	}
	
	public int getiAnzSchritte()
	{
		return this.iAnzSchritte;
	}

	public void setiAnzSchritte(int iAnzSchritte)
	{
		this.iAnzSchritte = iAnzSchritte;
	}

	/**
	 * @param sKoord
	 *        Gibt die Koordinaten des Feldes an, das der Benutzer aufdecken m�chte. Die Koordinaten werden
	 *        in der Form <ZeilenNr>/<SpaltenNr> angegeben. Bsp. 2/3 
	 * @return
	 *        Zur�ckgegeben wird ein Statuswert: 0 = Vor Beginn des n�chsten Zuges;
	 *                                           1 = 1. Feld aufgedeckt; 
	 *                                           2 = falsches 2. Feld aufgedeckt
	 *                                           3 = Memory komplett gel�st
	 * Kurzbeschreibung:
	 */
	public int waehleKoordinaten(String sKoord)
	{
		int iStatus = -1;

		if (pruefeKoord(sKoord))
		{
			switch (this.iZustand)
			{
			case 0: // Zustand 0: Start Zustand eines Zuges -> Erstes Feld wird aufgedeckt
				this.koordZustand1.setzeKoordinaten(sKoord);
				this.acMaske[this.koordZustand1.iX][this.koordZustand1.iY] = this.acVorlage[this.koordZustand1.iX][this.koordZustand1.iY];
				this.iZustand = 1;
				iStatus = 1;
				break;
			case 1: // Zustand 1: Erstes Feld ist aufgedeckt -> 2. Feld wird aufgedeckt und auf Richtigkeit gepr�ft
				this.iAnzSchritte++;
				this.koordZustand2.setzeKoordinaten(sKoord);
				this.acMaske[this.koordZustand2.iX][this.koordZustand2.iY] = this.acVorlage[this.koordZustand2.iX][this.koordZustand2.iY];
				
				if (this.acVorlage[this.koordZustand1.iX][this.koordZustand1.iY] == this.acVorlage[this.koordZustand2.iX][this.koordZustand2.iY])
				{
					this.iAnzRichtig++;
					
					if (this.iAnzRichtig == this.iAnzPaare) // Memory komplett gel�st -> Zustand 3
					{
						iStatus = 3;
						this.iZustand = 3;
					}
					else                                   // 1 Paar gefunden -> Zustand 0
					{
						iStatus = 0;
						this.iZustand = 0;
					}
				}
				else                                       // kein Paar gefunden -> Zustand 2
				{
					this.iZustand = 2;
					iStatus = 2;
				}
				break;

			case 2: // Zustand 2: Die beiden aufgedeckten Felder stimmen nicht �berein -> abdecken
				this.acMaske[this.koordZustand1.iX][this.koordZustand1.iY] = '#';
				this.acMaske[this.koordZustand2.iX][this.koordZustand2.iY] = '#';
				this.iZustand = 0; // weiter mit n�chstem Schritt
				iStatus = this.waehleKoordinaten(sKoord); // rekursiver Aufruf
				break;
				
			case 3: // Memory vollst�ndig gel�st -> es gibt nichts mehr zu tun
				iStatus = 3;
				break;
				
			default:
				break;
			}
			
		}
		
		return iStatus;
	}
	
	public boolean pruefeKoord(String sKoord)
	{
		// Bsp. Der regul�re Ausdruck "[1-4]/[1-4]" l�sst nur Koordinaten 
		//      Strings von 1/1 bis 4/4 zu.
		String sRegex = String.format("[1-%1$d]/[1-%1$d]",  acMaske.length);

		return sKoord.matches(sRegex);
	}

	public String zeigeAktuell()
	{
		StringBuilder sbMemory = new StringBuilder(" ");
		int iZeile, iSpalte;

		for (int i = 1; i <= acMaske.length * 2 + 1; i++)
		{
			if (i%2 == 0)  sbMemory.append(i/2); else sbMemory.append("-");
		}
		sbMemory.append("\n");

		for (iZeile = 0; iZeile < acMaske.length; iZeile++)
		{
			sbMemory.append(iZeile +1 + " ");

			for (iSpalte = 0; iSpalte < acMaske.length; iSpalte++)
			{
				sbMemory.append(acMaske[iZeile][iSpalte] + "|");

			}
			sbMemory.append("\n");
		}
		for (int i = 1; i <= acMaske.length * 2 + 1; i++)
		{
			sbMemory.append("-");
		}
		sbMemory.append("\n");
		return sbMemory.toString();
	}
	
	private class Koordinaten
	{
		public int iX;
		public int iY;
		
		public void setzeKoordinaten(String sKoord)
		{
			String[] sTeile = sKoord.split("/");
			iX = Integer.parseInt(sTeile[0]) - 1;
			iY = Integer.parseInt(sTeile[1]) - 1;
		}
		
	}
}



