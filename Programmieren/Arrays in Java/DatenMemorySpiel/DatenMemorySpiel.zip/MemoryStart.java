/**
 * MemoryStart.java
 * 05.02.2019
 */
package oopArrayAufg;

import input.Eingabe;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class MemoryStart
{

	/**
	 * @param args
	 * Kurzbeschreibung:
	 */
	public static void main(String[] args)
	{
		Memory meinMemory;
		int iStatus;
		int iAnzahlPaare;
		
		do
		{   // Gesamtzahl der Felder muss Quadratzahl sein
			iAnzahlPaare = Eingabe.getInt("Anzahl Paare (8, 18, 32) = ");
		} while (Math.sqrt(2 * iAnzahlPaare) % 1 != 0);
		
		meinMemory = new Memory(iAnzahlPaare);
		
		do
		{
			System.out.println(meinMemory.zeigeAktuell());
			iStatus = meinMemory.waehleKoordinaten(Eingabe.getString("Koordinaten ="));
			//System.out.println(iStatus);
			
		} while (iStatus != 3); // Status bedeutet: Memory gel�st
		
		
		System.out.println();
		
		System.out.println(meinMemory.zeigeAktuell());
		System.out.println("Super: Sie haben " + meinMemory.getiAnzSchritte() + "Schritte ben�tigt");
		
	}

}
