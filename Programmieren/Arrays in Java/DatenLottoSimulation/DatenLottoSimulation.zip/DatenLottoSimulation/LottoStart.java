/**
 * LottoStart.java
 * 24.01.2019
 */
package oopArrayAufg;

import java.time.LocalDate;

/**
 * @author stk
 * Kurzbeschreibung: Startklasse f�r Lotto Anwendung
 */
public class LottoStart
{

	/**
	 * @param args
	 * Kurzbeschreibung: Es wird jeweils ein Lotto Tipp generiert, dann eine
	 *                   Ziehung durchgef�hrt. Danach wird die Anzahl der
	 *                   Treffer angezeigt und die Zahlen der Ziehung in
	 *                   einer Statistik (H�ufigkeitsverteilung) erfasst.
	 *                   Nach Beendigung der Schleife wird die H�ufigkeits-
	 *                   verteilung in einem Histogramm angezeigt.
	 *                   
	 */
	public static void main(String[] args)
	{
		// Erzeuge Lottoschein f�r 6 (TIPP_ANZAHL) aus 49 
		LottoSchein meinLottoSchein = new LottoSchein(LottoZiehung.TIPP_ANZAHL);
		LottoZiehung eineLottoZiehung;
		LottoStatistik meineStatistik = new LottoStatistik(LottoZiehung.TIPP_MAX);
		MerkmalWertPaar[] aSortiert;
		
		for (int i = 1; i <= 100; i++)
		{
			meinLottoSchein.setSName("Max Mustermann");
			meinLottoSchein.setDatum(LocalDate.now());
			meinLottoSchein.generiereTipp();
			
			System.out.println(meinLottoSchein.toString());
			
			eineLottoZiehung = new LottoZiehung();
			eineLottoZiehung.setDatum(LocalDate.now());
			System.out.println(eineLottoZiehung.toString());
			
			System.out.println("Anzahl Richtige = " + eineLottoZiehung.ermittleTreffer(meinLottoSchein));
			
			meineStatistik.addiereZiehung(eineLottoZiehung);

		}
		System.out.println(schreibeHHistogr(meineStatistik.getaVerteilung()));

		aSortiert = meineStatistik.getNachH�ufigkeit();

		System.out.println(schreibeHHistogr(aSortiert));		
	}
	
	private static String schreibeHHistogr(MerkmalWertPaar[] aiStatistik)
	{
		int iMax = aiStatistik[0].getiWert();
		int iWert;
		
		// Maximalwert bestimmen
		for (int i = 1; i < aiStatistik.length; i++)
		{
			iWert = aiStatistik[i].getiWert();
			if (iWert > iMax)
			{
				iMax = iWert;
			}
		}
		
		StringBuilder sb = new StringBuilder(1000);
		for (int i = iMax; i > 0; i--)
		{
			for (int j = 0; j < aiStatistik.length; j++)
			{
				if (aiStatistik[j].getiWert() >= i)
				{
					sb.append("  *");
				}
				else
				{
					sb.append("   ");
				}
			}
			sb.append("\n");
		}
		for (int j = 0; j < aiStatistik.length; j++)
		{
			sb.append(String.format("%3d", aiStatistik[j].getiMerkmal()));
		}
		sb.append("\n");
		return sb.toString();
	}
}
