/**
 * ArrayToolsStart.java
 * 23.01.2019
 */
package oopArrayAufg;

import java.util.Arrays;

import input.Eingabe;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class ArrayToolsStart
{

	/**
	 * @param args
	 * Kurzbeschreibung:
	 */
	public static void main(String[] args)
	{
		int [] aiTest = {4, 7, 2, 9, 6, 3, 5, 8, 1 };
		int iIndex;
		int iSuchwert;
		
		iSuchwert = Eingabe.getInt("Welche Zahl soll gesucht werden ?");
		
		iIndex = ArrayTools.sucheSequenziell(aiTest, 0, aiTest.length - 1, iSuchwert);
		
		System.out.println(Arrays.toString(aiTest));
		
		System.out.println(iSuchwert + " hat den Index " + iIndex);
		
//		iIndex = ArrayTools.bestimmeMaxWert(aiTest, 0, aiTest.length - 1);
//		System.out.println("\nDas Array hat den Maxwert " + iIndex);
//		
//		iIndex = ArrayTools.bestimmeMinWert(aiTest, 0, aiTest.length - 1);
//		System.out.println("\nDas Array hat den Minwert " + iIndex);
//		
//		ArrayTools.sortiereZahlen(aiTest, 0, aiTest.length-1);
//		
//		System.out.println(Arrays.toString(aiTest));
//		
//		iIndex = ArrayTools.sucheBinaer(aiTest, 0, aiTest.length - 1, iSuchwert);
//		
//		System.out.println(iSuchwert + " hat den Index " + iIndex);
		
	}

}
