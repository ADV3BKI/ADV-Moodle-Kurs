/**
 * ArrayTools.java
 * 09.01.2019
 */
package oopArrayAufg;

/**
 * @author stk
 *
 *
 *         Kurzbeschreibung:
 */
public class ArrayTools
{
	public static int sucheSequenziell(int[] aiListe, int iVonInd, int iBisInd, int iSuchwert)
	{
		int iInd = -1;

		if (iVonInd >= 0 && iVonInd <= iBisInd && iBisInd <= aiListe.length - 1)
		{
			iInd = iVonInd;
			while (iInd <= iBisInd && aiListe[iInd] != iSuchwert)
			{
				iInd++;
			}
		}

		if (iInd > iBisInd)
			iInd = -1;

		return iInd;
	}
}
