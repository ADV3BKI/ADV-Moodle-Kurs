/**
 * KonvertiereUI.java
 * 21.02.2019
 */
package exceptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author stk
 *
 *
 *         Kurzbeschreibung:
 */
public class KonvertiereUI
{

	/**
	 * @param args
	 * Kurzbeschreibung:
	 */
	public static void main(String[] args) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int zahl = 0;
        String hexzahl;
        int wahl;

        do
        {
            System.out.println("\n(1) Dezimal --> Hexadezimal umrechnen");
            System.out.println("(2) Hexadezimal --> Dezimal umrechnen");
            System.out.println("(3) Programm beenden");
            System.out.println("-------------------------------------");
            System.out.print("Ihre Wahl: ");
            wahl = Integer.parseInt((br.readLine()));

            switch (wahl)
            {
                case 1:
                    System.out.print("Geben Sie eine Dezimalzahl ein: ");
                    zahl = Integer.parseInt((br.readLine()));
                    System.out.printf("Das entspricht Hexadezimal = %X\n", zahl);

                    break;
                case 2:
                    System.out.print("Geben Sie eine Hexzahl ein: ");
                    hexzahl = br.readLine();
                    zahl = LeseMethoden.hexToInt32(hexzahl);
                    System.out.printf("Das entspricht dezimal = %d\n", zahl);
                    break;
                default:
                    System.out.println("Programm beendet");
                    break;
            }
        } while (wahl != 3);

    }

}
