/**
 * LeseMethoden.java
 * 21.02.2019
 */
package exceptions;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class LeseMethoden
{
	static private int hexDigitToInt(char digit)
    {
        int wert = 0;

        if (digit >= '0' && digit <= '9')
            wert = digit - '0';
        else
            if (digit >= 'a' && digit <= 'f' || digit >= 'A' && digit <= 'F')
        {
            wert = 10 + Character.toLowerCase(digit) - 'a';
        }
        else
        {
            System.out.println("Nur Hexziffern erlaubt");
            System.exit(0);

        }

        return wert;
    }

    static public int hexToInt32(String input)
    {
        int ergebnis = 0;
        int length = input.length();

        for (int i = 0; i < length; i++)
        {
            ergebnis = (ergebnis * 16 + hexDigitToInt(input.charAt(i)));
        }

        return ergebnis;
    }
}
