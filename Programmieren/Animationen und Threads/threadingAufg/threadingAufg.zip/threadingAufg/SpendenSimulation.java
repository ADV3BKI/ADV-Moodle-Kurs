/**
 * SpendenSimulation.java
 * 25.06.2019
 */
package threadingAufg;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Random;

import input.Eingabe;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class SpendenSimulation
{
	private ArrayList<Sammler> sammlerListe;
	
	public SpendenSimulation()
	{
		this.sammlerListe = new ArrayList<>();
		
		this.sammlerEinlesen();
		this.sammlungStarten();
		this.ergebnisAnzeigen();
	}
	
	private void sammlerEinlesen()
	{
		Sammler einSammler;
		String  sName;
		
		sName = Eingabe.getString("Sammlername (Abbruch mit <Enter>): ");
		while (sName != null)
		{
			einSammler = new Sammler(sName);
			this.sammlerListe.add(einSammler);
			sName = Eingabe.getString("Sammlername (Abbruch mit <Enter>): ");
		}
	}
	
	private void sammlungStarten()
	{
		for (Sammler sammler : this.sammlerListe)
		{
			sammler.start();
		}
		
//		for (Sammler sammler : this.sammlerListe)
//		{
//			try
//			{
//				sammler.join();
//			}
//			catch (Exception e)
//			{
//				// TODO: handle exception
//			}
//		}

		System.out.println("\n\nSammelaktion beendet!");
	}
	
	private void ergebnisAnzeigen()
	{
		for (Sammler sammler : this.sammlerListe)
		{
			System.out.printf("Name: %-10s Dauer: %10.4f s  Betrag: %7.2f �\n",
				sammler.getsName(), sammler.berechneDauer()/1000.0, sammler.getdBetrag());
		}
	}
	
	// innere Klasse
	class Sammler extends Thread
	{
		private String sName;
		private double dBetrag;
		private long startZeitPunkt;
		private long endeZeitPunkt;
		private Random zufall;
		
		public Sammler(String sName)
		{
			this.sName = sName;
			this.dBetrag = 0;
			this.zufall = new Random();
		}
		
		public String getsName()
		{
			return this.sName;
		}

		public double getdBetrag()
		{
			return this.dBetrag;
		}
		
		public long berechneDauer()
		{
			return endeZeitPunkt - startZeitPunkt;
		}

		public void run()
		{
			this.startZeitPunkt = System.currentTimeMillis();
			while (this.dBetrag < 20)
			{
				dBetrag = dBetrag + simuliereSpende();
				simuliereWartezeit();
			}
			this.endeZeitPunkt = System.currentTimeMillis();
		}
		
		private double simuliereSpende()
		{
			double[] dMuenzen = {0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0, 2.0};
			return dMuenzen[zufall.nextInt(dMuenzen.length)];
		}
		
		private void simuliereWartezeit()
		{
			try
			{
				Thread.sleep((long)(zufall.nextDouble() * 90) + 10);
			}
			catch (Exception e) { }
		}
	}
}
