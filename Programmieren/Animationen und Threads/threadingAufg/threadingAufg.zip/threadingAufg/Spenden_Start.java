/**
 * Spenden_Start.java
 * 25.06.2019
 */
package threadingAufg;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class Spenden_Start
{
	/**
	 * @param args
	 * Kurzbeschreibung:
	 */
	public static void main(String[] args)
	{
		SpendenSimulation eineSimulation = new SpendenSimulation();
	}
}
