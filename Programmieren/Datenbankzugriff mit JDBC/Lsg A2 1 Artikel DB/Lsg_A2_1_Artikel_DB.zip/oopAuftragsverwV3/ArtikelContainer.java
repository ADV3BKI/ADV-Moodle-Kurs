package oopAuftragsverwV3;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class ArtikelContainer
{
	private List<Artikel> alleArtikel;
	
	/**
	 * Konstruktor, erzeugt Array f�r max 20 Artikel (wird dynamisch verl�ngert)
	 */
	public ArtikelContainer()
	{
		//this.alleArtikel = new ArrayList<Artikel>(20);
		this(20);
	}

	/**
	 *
	 * Konstruktor, erzeugt Array f�r iAnzArtikel Artikel
	 * 
	 * @param iKapazitaet
	 *            L�nge des Start Arrays (wird dynamisch verl�ngert)
	 * 
	 */
	public ArtikelContainer(int iKapazitaet)
	{
		this.alleArtikel = new ArrayList<Artikel>(iKapazitaet);
	}
	
	public boolean speichereArtikelDaten(Path artikelDatei)
	{
		boolean status = true;
		
		try (ObjectOutputStream oos = 
				new ObjectOutputStream (
				   new BufferedOutputStream(
					 Files.newOutputStream(artikelDatei,StandardOpenOption.CREATE,
							                            StandardOpenOption.TRUNCATE_EXISTING))))
		{
			// Persistieren der einzelnen Artikel nacheinander in serialisierter Form
			for (Artikel artikel : this.alleArtikel)
			{
				oos.writeObject(artikel);
			}
			
		}
		catch (Exception e)
		{
			status = false;
		}
		return status;
	}

	public boolean leseArtikelDaten(Path artikelDatei)
	{
		boolean status = true;
		Artikel neuerArtikel;
		int iAnzahl = 0;
		
		try (ObjectInputStream ois = 
				new ObjectInputStream (
				   new BufferedInputStream(
					 Files.newInputStream(artikelDatei))))
		{
			// Lesen der einzelnen Artikel nacheinander
			do
			{
				neuerArtikel = (Artikel)ois.readObject();
				// Einf�gen des gelesenen Artikel-Objekts in die ArrayList
				this.alleArtikel.add(neuerArtikel);
				iAnzahl++;
			} while (true); // Endet durch EOF
		}
		catch (Exception e)
		{
			// Bei EOFException soll true zur�ckgegeben werden
			if (iAnzahl == 0)
			{ // Wenn die Anzahl 0 ist, dann ist wohl ein Fehler aufgetreten
				status = false;
			}
		}
		return status;
	}

	
	public boolean speichereArtikelListe(Path artikelDatei)
	{
		boolean status = true;
		
		try (ObjectOutputStream oos = 
				new ObjectOutputStream (
				   new BufferedOutputStream(
					 Files.newOutputStream(artikelDatei,StandardOpenOption.CREATE,
							                            StandardOpenOption.TRUNCATE_EXISTING))))
		{
			// Persistieren der komplettenm ArrayList mit den Artikel in serialisierter Form
			oos.writeObject(alleArtikel);
			
		}
		catch (Exception e)
		{
			status = false;
		}
		return status;
	}

	@SuppressWarnings("unchecked")
	public boolean leseArtikelListe(Path artikelDatei)
	{
		boolean status = true;
		
		try (ObjectInputStream ois = 
				new ObjectInputStream (
				   new BufferedInputStream(
					 Files.newInputStream(artikelDatei))))
		{
			// Lesen der komplettenm ArrayList mit den Artikel (Deserialisieren)
			alleArtikel = (ArrayList<Artikel>)ois.readObject();
		}
		catch (Exception e)
		{
			status = false;
		}
		return status;
	}
	
	public boolean leseArtikelTabelle()
	{
		boolean status = true;
		DBHandler db = new DBHandler();
		
		db.DBConnect("IT_Center_v2012");
		status = db.getDbconOK();
		
		if (status)
		{
			String sQuery = "select ArtikelNr, ArtikelName, Artikelgruppe, Einstandspreis, "
					+ "Lagerbestand from Artikel";
			ResultSet rs = db.DBQuery(sQuery);
			
			try
			{
				while (rs.next())
				{
					speichereDatensatz(rs);
				}
			}
			catch (Exception e)
			{
				status = false;
			}
			
		}
		return status;
	}

	private void speichereDatensatz(ResultSet rs) throws SQLException
	{
		Artikel neuerArtikel = new Artikel();
		
		neuerArtikel.setINr(Integer.parseInt(rs.getString("ArtikelNr")));
		neuerArtikel.setSBezeichnung(rs.getString("ArtikelName"));
		neuerArtikel.setSArtikelgruppe(rs.getString("Artikelgruppe"));
		neuerArtikel.setDVerkaufsPreis(rs.getFloat("Einstandspreis"));
		
		// Einf�gen des gelesenen Artikel-Objekts in die ArrayList
		this.alleArtikel.add(neuerArtikel);
	}
	
	/**
	 * @return liefert aktuelle Anzahl gespeicherter Artikel
	 */
	public int getIAnzAkt()
	{
		return this.alleArtikel.size();
	}

	/**
	 * neuerArtikel wird in Array gespeichert und die Anzahl aktualisiert
	 * 
	 * @param neuerArtikel
	 *            Verweis auf Artikelobjekt das gespeichert werden soll
	 * 
	 */
	public void speichereArtikel(Artikel neuerArtikel)
	{
		this.alleArtikel.add(neuerArtikel);
	}
	
	
	
	/**
	 * alle Artikel des Containers werden in Form eines Arrays zur�ckgeliefert
	 * 
	 * @param keine
	 * @return Artikel [] mit den gesuchten Artikeln; L�nge des Arrays = Anzahl
	 * der gefundenen Artikel; falls kein Artikel gefunden wird ist die R�ckgabe null
	 * 
	 */
	public Artikel[] abrufenArtikel()
	{
		Artikel[] artikel = null;
		if (alleArtikel.size() > 0)
		{
			artikel = alleArtikel.toArray(new Artikel[0]);
		}
		return  artikel; // null, wenn nichts gefunden
	}

	/**
	 * Sucht den Artikel der die gegebene iArtikelNr besitzt;
	 * Es wird davon ausgegangen, dass Artikelnummern eindeutig sind.
	 * 
	 * @param iArtikelNr
	 * Artikel mit dieser Nummer wird gesucht
	 * @return
	 * Ist der gesuchte Artikel vorhanden, so wird ein Verweis darauf zur�ckgegeben,
	 * null sonst.
	 * 
	 */
	public Artikel sucheArtikelNachNr(int iArtikelNr)
	{
		Artikel gesucht = null;
		Artikel aktuell;
		Iterator<Artikel> it = alleArtikel.iterator(); // 3 P
		
		while (gesucht == null && it.hasNext()) // 2 P
		{
			aktuell = it.next();  // 1 P
			if (aktuell.getINr() == iArtikelNr) // 2 P
				gesucht = aktuell; // 1 P
			
		}
//		int iInd = 0;
//
//		while (iInd < this.alleArtikel.size() && this.alleArtikel.get(iInd).getINr() != iArtikelNr)
//		{
//			iInd++;
//		}
//		
//		if (iInd < this.alleArtikel.size()) // ArtikelNr wurde gefunden
//		{
//			gesucht = this.alleArtikel.get(iInd);
//		}

		return gesucht; // null, wenn nicht gefunden // 1 P

	}

	/**
	 * sucht alle Artikel mit sBezeichnung == sSuchBezeichnung
	 * 
	 * @param sSuchBezeichnung
	 *            Artikel mit dieser Bezeichnung werden gesucht und zur�ckgegeben
	 * @return Artikel [] mit den gesuchten Artikeln; L�nge des Arrays = Anzahl
	 * der gefundenen Artikel; falls kein Artikel gefunden wird ist die R�ckgabe null
	 * 
	 * <br><br>Es wird davon ausgegangen, dass es mehrere Artikel mit der gleichen
	 * Bezeichnung geben kann. Deshalb soll ein Artikel Array zur�ckgegeben werden
	 * Das Array hat genau die L�nge der gefundenen Artikel. <br>
	 * Die gefundenen Artikel werden zun�chst in einer LinkedList gespeichert.
	 * Vor der R�ckgabe wird die LinkedList in ein Array konvertiert, das
	 * genau so lang ist, wie die Zahl der gefundenen Artikel
	 */
	public Artikel[] sucheArtikelNachBezeichnung(String sSuchBezeichnung)
	{
		List<Artikel> gefundeneArtikel = new LinkedList<>();

		for (Artikel einArtikel: this.alleArtikel)
		{
			if (einArtikel.getSBezeichnung().equals(sSuchBezeichnung))
			{
				gefundeneArtikel.add(einArtikel);
			}
		}
		return gefundeneArtikel.toArray(new Artikel[0]); // null, wenn nichts gefunden
	}
}
