/**
 * AuftragsVerwContGUI.java
 * 25.03.2019
 */
package oopAuftragsverwV3;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import input.Eingabe;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.Font;

/**
 * @author stk
 *
 *
 *         Kurzbeschreibung:
 */
public class AuftragsVerwContGUI
{
	// Attribute der GUI Klasse
	private ArtikelContainer artikelListe = new ArtikelContainer();
	private Artikel[] aArtikelGefunden = null;
	private int iAktIndex;
	private Path artikelDatei;
	private JFrame frmArtikelverwaltung;
	private JFormattedTextField txtArtikelNr;
	private JTextField txtBezeichung;
	private JFormattedTextField fxtPreis;
	private JButton btnSpeichern;
	private JButton btnAlleArtikel;
	private JButton btnSuchenNr;
	private JButton btnSuchenName;
	private JButton btnVorwaerts;
	private JButton btnRueckwaerts;
	private JLabel lblStatus;
	private final Font frmFont = new Font("Tahoma", Font.PLAIN, 18);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					AuftragsVerwContGUI window = new AuftragsVerwContGUI();
					window.frmArtikelverwaltung.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AuftragsVerwContGUI()
	{
		initialize();
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(frmArtikelverwaltung, "Look and Feel Fehler");
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize()
	{
		UIManager.getDefaults().put("Button.disabledText",Color.LIGHT_GRAY);
		frmArtikelverwaltung = new JFrame();
		frmArtikelverwaltung.setFont(frmFont);
		frmArtikelverwaltung.setTitle("Artikelverwaltung");
		frmArtikelverwaltung.setBounds(100, 100, 757, 426);
		frmArtikelverwaltung.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmArtikelverwaltung.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));

		JPanel pnlEinAusgabe = new JPanel();
		pnlEinAusgabe.setBorder(new EmptyBorder(15, 15, 15, 15));
		frmArtikelverwaltung.getContentPane().add(pnlEinAusgabe);
		pnlEinAusgabe.setLayout(new GridLayout(0, 3, 0, 0));

		JLabel lblArtikelNr = new JLabel("ArtikelNr");
		lblArtikelNr.setFont(frmFont);
		pnlEinAusgabe.add(lblArtikelNr);

		txtArtikelNr = new JFormattedTextField(NumberFormat.getNumberInstance());
		txtArtikelNr.setFont(frmFont);
		txtArtikelNr.setValue(new Integer(0));
		pnlEinAusgabe.add(txtArtikelNr);
		txtArtikelNr.setColumns(10);

		JLabel lblLeer = new JLabel("");
		pnlEinAusgabe.add(lblLeer);

		JLabel lblBezeichung = new JLabel("Bezeichung");
		lblBezeichung.setFont(frmFont);
		pnlEinAusgabe.add(lblBezeichung);

		txtBezeichung = new JTextField();
		txtBezeichung.setFont(frmFont);
		txtBezeichung.setText("- Bez. eingeben -");
		txtBezeichung.setColumns(30);
		pnlEinAusgabe.add(txtBezeichung);

		JLabel lblLeer2 = new JLabel("");
		pnlEinAusgabe.add(lblLeer2);

		JLabel lblVerkaufsPreis = new JLabel("Verkaufspreis");
		lblVerkaufsPreis.setFont(frmFont);
		pnlEinAusgabe.add(lblVerkaufsPreis);

		fxtPreis = new JFormattedTextField(NumberFormat.getNumberInstance());
		fxtPreis.setFont(frmFont);
		fxtPreis.setValue(new Double(0));
		pnlEinAusgabe.add(fxtPreis);

		JLabel lblEuro = new JLabel("    \u20AC");
		lblEuro.setFont(frmFont);
		pnlEinAusgabe.add(lblEuro);

		JPanel pnlButtons = new JPanel();
		frmArtikelverwaltung.getContentPane().add(pnlButtons);

		JPanel pnlButtonsAktion = new JPanel();
		pnlButtons.add(pnlButtonsAktion);
		pnlButtonsAktion.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		btnSpeichern = new JButton("\u00DCbernehmen");
		btnSpeichern.setFont(frmFont);
		pnlButtonsAktion.add(btnSpeichern);

		btnAlleArtikel = new JButton("Alle abrufen");
		btnAlleArtikel.setFont(frmFont);
		pnlButtonsAktion.add(btnAlleArtikel);

		btnSuchenNr = new JButton("Suche nach Nummer...");
		btnSuchenNr.setFont(frmFont);
		pnlButtonsAktion.add(btnSuchenNr);

		btnSuchenName = new JButton("Suchen nach Name ...");
		btnSuchenName.setFont(frmFont);
		pnlButtonsAktion.add(btnSuchenName);
		
		btnVorwaerts = new JButton("  >>  ");
		pnlButtons.add(btnVorwaerts);
		btnVorwaerts.setFont(frmFont);
		btnVorwaerts.setEnabled(false);
		btnVorwaerts.addActionListener(new BtnActionListener());

		JPanel pnlNavigation = new JPanel();
		pnlButtons.add(pnlNavigation);

		btnRueckwaerts = new JButton("  <<  ");
		btnRueckwaerts.setFont(frmFont);
		pnlNavigation.add(btnRueckwaerts);
		btnRueckwaerts.setEnabled(false);

		JPanel pnlStatus = new JPanel();
		frmArtikelverwaltung.getContentPane().add(pnlStatus);

		lblStatus = new JLabel("Status: Programm gestartet");
		lblStatus.setFont(frmFont);
		pnlStatus.add(lblStatus);

		JMenuBar menuBar = new JMenuBar();
		frmArtikelverwaltung.setJMenuBar(menuBar);

		JMenu mnNewMenu = new JMenu("Datei");
		mnNewMenu.setFont(new Font("Tahoma", Font.PLAIN, 18));
		menuBar.add(mnNewMenu);

		JMenuItem mntmArtikeldatenLaden = new JMenuItem("Artikeldaten laden...");
		mntmArtikeldatenLaden.setFont(frmFont);
		mntmArtikeldatenLaden.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser dateiAuswahl = new JFileChooser();
				boolean bOK;
				dateiAuswahl.setFont(frmFont);
				dateiAuswahl.setFileFilter(new FileNameExtensionFilter("Artikel Dateien", "dat"));
				if (dateiAuswahl.showOpenDialog(frmArtikelverwaltung) == JFileChooser.APPROVE_OPTION)
				{
					artikelDatei = Paths.get(dateiAuswahl.getSelectedFile().getPath());
					bOK = artikelListe.leseArtikelDaten(artikelDatei);
					if (bOK)
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeldaten wurden geladen");
						abrufenArtikel();
					}
					else
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeldaten konnten nicht geladen werden",
								"Fehler", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		mnNewMenu.add(mntmArtikeldatenLaden);

		JMenuItem mntmArtikeldatenSpeichern = new JMenuItem("Artikeldaten speichern...");
		mntmArtikeldatenSpeichern.setFont(frmFont);
		mntmArtikeldatenSpeichern.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser dateiAuswahl = new JFileChooser();
				dateiAuswahl.setFont(frmFont);
				dateiAuswahl.setFileFilter(new FileNameExtensionFilter("Artikel Dateien", "dat"));
				if (dateiAuswahl.showSaveDialog(frmArtikelverwaltung) == JFileChooser.APPROVE_OPTION)
				{
					// Die Datei soll automatisch die Endung .dat erhalten
					artikelDatei = Paths.get(dateiAuswahl.getSelectedFile().getAbsolutePath() + ".dat");
					if (artikelListe.speichereArtikelDaten(artikelDatei))
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, 
								"Artikeldaten wurden gespeichert");
					}
					else
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung,
								"Artikeldaten konnten nicht gespeichert werden", "Fehler", 
								JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		mnNewMenu.add(mntmArtikeldatenSpeichern);
		
		JMenuItem mntmContainerLaden = new JMenuItem("Container laden...");
		mntmContainerLaden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser dateiAuswahl = new JFileChooser();
				boolean bOK;
				dateiAuswahl.setFont(frmFont);
				dateiAuswahl.setFileFilter(new FileNameExtensionFilter("Artikel Dateien", "lst"));
				if (dateiAuswahl.showOpenDialog(frmArtikelverwaltung) == JFileChooser.APPROVE_OPTION)
				{
					artikelDatei = Paths.get(dateiAuswahl.getSelectedFile().getPath());
					bOK = artikelListe.leseArtikelListe(artikelDatei);
					if (bOK)
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeldaten wurden geladen");
						abrufenArtikel();
					}
					else
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeldaten konnten nicht geladen werden",
								"Fehler", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		mnNewMenu.add(mntmContainerLaden);
		
		JMenuItem mntmContainerSpeichern = new JMenuItem("Container speichern...");
		mntmContainerSpeichern.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser dateiAuswahl = new JFileChooser();
				dateiAuswahl.setFont(frmFont);
				dateiAuswahl.setFileFilter(new FileNameExtensionFilter("Artikel Dateien", "lst"));
				if (dateiAuswahl.showSaveDialog(frmArtikelverwaltung) == JFileChooser.APPROVE_OPTION)
				{
					// Die Datei soll automatisch die Endung .lst erhalten
					artikelDatei = Paths.get(dateiAuswahl.getSelectedFile().getAbsolutePath()+".lst");
					if (artikelListe.speichereArtikelListe(artikelDatei))
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung, 
								"Artikeldaten wurden gespeichert");
					}
					else
					{
						JOptionPane.showMessageDialog(frmArtikelverwaltung,
								"Artikeldaten konnten nicht gespeichert werden", "Fehler", 
								JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		mnNewMenu.add(mntmContainerSpeichern);
		
		JMenu mnNewMenu2 = new JMenu("Datenbank");
		mnNewMenu2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		menuBar.add(mnNewMenu2);
		
		JMenuItem mntmNewArtikelTabLaden = new JMenuItem("Artikeltabelle Laden");
		mntmNewArtikelTabLaden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (artikelListe.leseArtikelTabelle())
				{
					JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeltabelle wurde geladen");
					abrufenArtikel();
				}
				else
				{
					JOptionPane.showMessageDialog(frmArtikelverwaltung, "Artikeltabelle konnten nicht geladen werden",
							"Fehler", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		mntmNewArtikelTabLaden.setFont(new Font("Tahoma", Font.PLAIN, 18));
		mnNewMenu2.add(mntmNewArtikelTabLaden);

		// Action Listener registrieren
		txtArtikelNr.addActionListener(new BtnActionListener());
		txtBezeichung.addActionListener(new BtnActionListener());
		fxtPreis.addActionListener(new BtnActionListener());
		btnSpeichern.addActionListener(new BtnActionListener());
		btnAlleArtikel.addActionListener(new BtnActionListener());
		btnSuchenNr.addActionListener(new BtnActionListener());
		btnSuchenName.addActionListener(new BtnActionListener());
		btnRueckwaerts.addActionListener(new BtnActionListener());
	}

	private void abrufenArtikel()
	{
		String sArtikelBez;
		Artikel einArtikel;

		aArtikelGefunden = artikelListe.abrufenArtikel();
		if (aArtikelGefunden != null)
		{
			iAktIndex = 0;
			txtArtikelNr.setText(Integer.toString(aArtikelGefunden[iAktIndex].getINr()));
			txtBezeichung.setText(aArtikelGefunden[iAktIndex].getSBezeichnung());
			fxtPreis.setValue(aArtikelGefunden[iAktIndex].getDVerkaufsPreis());
			lblStatus.setText(
					"Status: #" + (iAktIndex + 1) + " von " + aArtikelGefunden.length + " gefundenen Artikel(n)");
			if (aArtikelGefunden.length >= 1)
			{
				btnVorwaerts.setEnabled(true);
				btnRueckwaerts.setEnabled(true);
			}
		}
	}

	private class BtnActionListener implements ActionListener
	{
		// Innere Klasse f�r den Action Listener
		@Override
		public void actionPerformed(ActionEvent e)
		{
			if (e.getSource() == btnSpeichern)
			{
				speichern();
			}
			else
				if (e.getSource() == btnSuchenNr)
				{
					suchenNachNr();
				}
				else
					if (e.getSource() == btnAlleArtikel)
					{
						abrufenArtikel();
					}
					else
						if (e.getSource() == btnSuchenName)
						{
							suchenNachName();
						}
						else
							if (e.getSource() == btnVorwaerts)
							{
								zeigenVorwaerts();
							}
							else
								if (e.getSource() == btnRueckwaerts)
								{
									zeigenRueckwaerts();
								}
		}

		private void speichern()
		{
			Artikel einArtikel;
			int iArtikelNr = ((Number)txtArtikelNr.getValue()).intValue();
			double dEuro = ((Number) fxtPreis.getValue()).doubleValue();
			einArtikel = new Artikel(iArtikelNr, txtBezeichung.getText(), dEuro);
			artikelListe.speichereArtikel(einArtikel);
			lblStatus.setText("Status: Artikel gespeichert");
			btnVorwaerts.setEnabled(false);
			btnRueckwaerts.setEnabled(false);
		}

		private void suchenNachNr()
		{
			String sNummer;
			Artikel einArtikel;

			sNummer = (String) JOptionPane.showInputDialog(frmArtikelverwaltung, "Bitte ArtikelNr eingeben:");

			einArtikel = artikelListe.sucheArtikelNachNr(Integer.parseInt(sNummer));
			if (einArtikel != null)
			{
				txtArtikelNr.setText(sNummer);
				txtBezeichung.setText(einArtikel.getSBezeichnung());
				fxtPreis.setValue(einArtikel.getDVerkaufsPreis());
				// txtPreis.setText(String.format("%.2f", einArtikel.getDVerkaufsPreis());
				lblStatus.setText("Status: Artikel " + sNummer + " gefunden");
				btnVorwaerts.setEnabled(false);
				btnRueckwaerts.setEnabled(false);
			}
			else
				lblStatus.setText("Status: Artikel mit Nummer " + sNummer + " nicht gefunden");

		}

		private void suchenNachName()
		{
			String sArtikelBez;
			Artikel einArtikel;

			sArtikelBez = (String) JOptionPane.showInputDialog(frmArtikelverwaltung,
					"<html><div  style='font-size:18'>Bitte Artikelbezeichnung eingeben:</div></html>");
			if (sArtikelBez != null)
			{
				aArtikelGefunden = artikelListe.sucheArtikelNachBezeichnung(sArtikelBez);
				if (aArtikelGefunden != null)
				{
					iAktIndex = 0;
					txtArtikelNr.setText(Integer.toString(aArtikelGefunden[iAktIndex].getINr()));
					txtBezeichung.setText(aArtikelGefunden[iAktIndex].getSBezeichnung());
					fxtPreis.setValue(aArtikelGefunden[iAktIndex].getDVerkaufsPreis());
					lblStatus.setText("Status: #" + (iAktIndex + 1) + " von " + aArtikelGefunden.length
							+ " gefundenen Artikel(n)");
					if (aArtikelGefunden.length > 1)
					{
						btnVorwaerts.setEnabled(true);
						btnRueckwaerts.setEnabled(true);
					}
					else
					{
						btnVorwaerts.setEnabled(false);
						btnRueckwaerts.setEnabled(false);
					}
				}
			}
		}

		private void zeigenVorwaerts()
		{
			if (iAktIndex < aArtikelGefunden.length - 1)
			{
				iAktIndex++;
			}
			else
			{
				iAktIndex = 0;
			}

			txtArtikelNr.setText(Integer.toString(aArtikelGefunden[iAktIndex].getINr()));
			txtBezeichung.setText(aArtikelGefunden[iAktIndex].getSBezeichnung());
			fxtPreis.setValue(aArtikelGefunden[iAktIndex].getDVerkaufsPreis());
			lblStatus.setText(
					"Status: #" + (iAktIndex + 1) + " von " + aArtikelGefunden.length + " gefundenen Artikel(n)");
		}

		private void zeigenRueckwaerts()
		{
			if (iAktIndex > 0)
			{
				iAktIndex--;
			}
			else
			{
				iAktIndex = aArtikelGefunden.length - 1;
			}

			txtArtikelNr.setText(Integer.toString(aArtikelGefunden[iAktIndex].getINr()));
			txtBezeichung.setText(aArtikelGefunden[iAktIndex].getSBezeichnung());
			fxtPreis.setValue(aArtikelGefunden[iAktIndex].getDVerkaufsPreis());
			lblStatus.setText(
					"Status: #" + (iAktIndex + 1) + " von " + aArtikelGefunden.length + " gefundenen Artikel(n)");
		}

	}
}
