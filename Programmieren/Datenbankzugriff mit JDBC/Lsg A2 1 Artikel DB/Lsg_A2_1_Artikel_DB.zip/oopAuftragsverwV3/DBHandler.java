/**
 * DBHandler.java
 * 05.07.2022
 */
package oopAuftragsverwV3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import jdbc_Demo.Daten;

/**
 * @author stk
 *
 *
 *         Kurzbeschreibung:
 */
public class DBHandler implements DBDaten
{
	private Connection con;
	private boolean dbconOK;
	private String errorStr;

	public DBHandler()
	{
		con = null;
		dbconOK = false;
		errorStr = "Keine DB Verbindung aufgebaut!";
	}

	public boolean getDbconOK()
	{
		return dbconOK;
	}

	public String getErrorStrK()
	{
		return errorStr;
	}

	public void DBConnect(String dbName)
	{
		try
		{
			Class.forName(dbTreiber);
			// Verbindungsstring:
			// "jdbc:mariadb://localhost:3306/u_itc_formular?user=kds&password=kds2000"
			String s = "jdbc:mariadb://" + host + ":" + port + "/" + dbName + "?" + "user=" + user + "&" + "password="
					+ passwd;

			con = DriverManager.getConnection(s);
			dbconOK = true;
		}
		catch (Exception e)
		{
			errorStr = "DBOpen: " + e.getMessage();
			dbconOK = false;
		}
	}

	public ResultSet DBQuery(String sqlString)
	{
		ResultSet reader = null;

		try (Statement cmd = con.createStatement())
		{
			reader = cmd.executeQuery(sqlString);
			dbconOK = true;
		}
		catch (Exception e)
		{
			errorStr = "DBQuery: " + e.getMessage();
			dbconOK = false;
		}
		return reader;
	}

	public void DBClose()
	{
		try
		{
			if (con.isValid(10))
				con.close();
		}
		catch (Exception e)
		{
			errorStr = "DBClose: " + e.getMessage();
		}
	}

}
