package oopAuftragsverwV3;

public interface DBDaten
{
	// Datenbank-Verbindungsdaten
	public static final String dbTreiber = "org.mariadb.jdbc.Driver"; // Treiberklasse
	public static final String host 	 = "localhost";	 	// Datenbankserver (IP-Angeben)
	public static final String port 	 = "3306"; 			// JDBC/ODBC-Port
	public static final String db 		 = "IT_Center_v2012"; 	// Datenbankname
	public static final String user 	 = "kds"; 		    // Datenbank-User
	public static final String passwd 	 = "kds2000"; 			// Passwort
	public static final String table 	 = "personen"; 		// Tabellenname
}
