package oopAuftragsVerwV2;

import java.util.Arrays;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class ArtikelContainer
{
	private Artikel[] alleArtikel;
	private int iAnzAkt;
	
	/**
	 * Konstruktor, erzeugt Array f�r max 20 Artikel (wird dynamisch verl�ngert)
	 */
	public ArtikelContainer()
	{
//		this.alleArtikel = new Artikel[20];
//		iAnzAkt = 0;
		this(20); // Konstruktor-Verkettung
	}

	/**
	 *
	 * Konstruktor, erzeugt Array f�r iAnzArtikel Artikel
	 * 
	 * @param iMaxArtikel
	 *            L�nge des Start Arrays (wird dynamisch verl�ngert)
	 * 
	 */
	public ArtikelContainer(int iMaxArtikel)
	{
		this.alleArtikel = new Artikel[iMaxArtikel];
		iAnzAkt = 0;
	}

	/**
	 * @return liefert aktuelle Anzahl gespeicherter Artikel
	 */
	public int getIAnzAkt()
	{
		return this.iAnzAkt;
	}

	/**
	 * neuerArtikel wird in Array gespeichert und die Anzahl aktualisiert
	 * 
	 * @param neuerArtikel
	 *            Verweis auf Artikelobjekt das gespeichert werden soll
	 * 
	 *            <br>Ist das Array voll so wird es automatisch auf die doppelte L�nge
	 *            vergr��ert
	 * 
	 */
	public void speichereArtikel(Artikel neuerArtikel)
	{
		if (this.iAnzAkt == this.alleArtikel.length) // wenn Array voll
		{   // Verl�ngern auf doppelte L�nge
			this.alleArtikel = Arrays.copyOf(this.alleArtikel, alleArtikel.length * 2);
		}
		this.alleArtikel[iAnzAkt] = neuerArtikel;
		iAnzAkt++;
	}

	/**
	 * Sucht den Artikel der die gegebene iArtikelNr besitzt;
	 * Es wird davon ausgegangen, dass Artikelnummern eindeutig sind.
	 * 
	 * @param iArtikelNr
	 * Artikel mit dieser Nummer wird gesucht
	 * @return
	 * Ist der gesuchte Artikel vorhanden, so wird ein Verweis darauf zur�ckgegeben,
	 * null sonst.
	 * 
	 */
	public Artikel sucheArtikelNachNr(int iArtikelNr)
	{
		Artikel gesucht = null;
		int iInd = 0;

		while (iInd < this.iAnzAkt && this.alleArtikel[iInd].getINr() != iArtikelNr)
		{
			iInd++;
		}
		
		if (iInd < this.iAnzAkt) // ArtikelNr wurde gefunden
		{
			gesucht = this.alleArtikel[iInd];
		}

		return gesucht; // null, wenn nicht gefunden

	}

	/**
	 * sucht alle Artikel mit sBezeichnung == sSuchBezeichnung
	 * 
	 * @param sSuchBezeichnung
	 *            Artikel mit dieser Bezeichnung werden gesucht und zur�ckgegeben
	 * @return Artikel [] mit den gesuchten Artikeln; L�nge des Arrays = Anzahl
	 * der gefundenen Artikel; falls kein Artikel gefunden wird ist die R�ckgabe null
	 * 
	 * <br><br>Es wird davon ausgegangen, dass es mehrere Artikel mit der gleichen
	 * Bezeichnung geben kann. Deshalb soll ein Artikel Array zur�ckgegeben werden
	 * Das Array hat genau die L�nge der gefundenen Artikel. <br>
	 * Vorgehensweise: Artikel[] Verweis anlegen; Wenn ein Artikel gefunden wird,
	 * dann Array der L�nge 1 erzeugen. Falls weiterer Artikel gefunden wird, neues
	 * um ein Element verl�ngertes Array Objekt durch Kopieren (Arrays.copyOf())
	 * erzeugen und darauf verweisen. 
	 */
	public Artikel[] sucheArtikelNachBezeichnung(String sSuchBezeichnung)
	{
		Artikel[] gefundeneArtikel = null;
		int iAnz = 0;
		for (int i = 0; i < this.iAnzAkt; i++)
		{
			if (this.alleArtikel[i].getSBezeichnung().equals(sSuchBezeichnung))
			{
				if (gefundeneArtikel == null) gefundeneArtikel = new Artikel[1];
				if (iAnz == gefundeneArtikel.length) // gilt ab dem 2. gefundenen Artikel
					gefundeneArtikel = Arrays.copyOf(gefundeneArtikel,
							                         gefundeneArtikel.length + 1);
				gefundeneArtikel[iAnz] = this.alleArtikel[i];
				iAnz++;
			}
		}
		return gefundeneArtikel; // null, wenn nichts gefunden
	}
}
