/**
 * AuftragsVerwContUI.java
 * 31.12.2018
 */
package oopAuftragsVerwV2;

import input.Eingabe;

/**
 * @author stk
 *
 *         Kurzbeschreibung: UI-Klasse zur Auftragsverwaltung
 */
public class AuftragsVerwContUI
{
	/**
	 * @param args
	 *            Kurzbeschreibung:
	 */
	public static void main(String[] args)
	{
		Artikel einArtikel = null, aArtikel[];
		ArtikelContainer artikelListe = new ArtikelContainer();
		int iArtikelNr = 0;
		double dVPreis;
		int iAuswahl;
		String sArtikelBez;

		do
		{
			iArtikelNr = Eingabe.getInt("ArtikelNr = ");
			if (iArtikelNr != -1)
			{
				dVPreis = Eingabe.getDouble("Verkaufspreis = ");
				einArtikel = new Artikel(iArtikelNr,
						"TollerArtikel" /* + (Artikel.getiAnzahlErzeugterObjekte() + 1 ) */, dVPreis);
				System.out.printf("Artikel %s Bruttopreis: %f\n\n", einArtikel.getSBezeichnung(),
						einArtikel.getDVerkaufsPreisBrutto());
				artikelListe.speichereArtikel(einArtikel);
			}
		} while (iArtikelNr != -1);

		System.out.printf("Anzahl erzeugter Artikel %d\n\n", Artikel.getiAnzahlErzeugterObjekte());
		Artikel.setdMehrwertsteuersatz(0.20);

		do
		{
			iAuswahl = Eingabe.getInt("Wie wollen Sie einen Artikel Suchen?\n" + "(1) nach ArtikelNr\n"
					+ "(2) nach ArtikelBezeichnung\n" + "(3) keine Suche (Ende)\n");

			switch (iAuswahl)
			{
			case 1:
				iArtikelNr = Eingabe.getInt("ArtikelNr = ");
				einArtikel = artikelListe.sucheArtikelNachNr(iArtikelNr);
				if (einArtikel != null)
				{
					System.out.printf("Artikel %s Bruttopreis: %f\n\n", einArtikel.getSBezeichnung(),
							einArtikel.getDVerkaufsPreisBrutto());
				}
				break;

			case 2:
				sArtikelBez = Eingabe.getString("Bezeichung = ");
				aArtikel = artikelListe.sucheArtikelNachBezeichnung(sArtikelBez);
				if (aArtikel != null)
				{
					for (Artikel artikel : aArtikel)
					{
						System.out.printf("Artikel %s Bruttopreis: %f\n\n", artikel.getSBezeichnung(),
								artikel.getDVerkaufsPreisBrutto());
					}
				}
				break;
			default:
				break;
			}

		} while (iAuswahl == 1 || iAuswahl == 2);

	}

}
