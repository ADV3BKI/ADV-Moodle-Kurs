/**
 * Artikel2SortUI.java
 * 19.02.2019
 */
package oopInterface;

import java.util.Arrays;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class Artikel2SortUI
{

	/**
	 * @param args
	 * Kurzbeschreibung: Start-UI-Klasse zum Test des Sortierens
	 */
	public static void main(String[] args)
	{
		Artikel2[] aListe = { new Artikel2(3711, "Ladenh�ter", 25.60),
				              new Artikel2(3722, "TopSeller", 5.60),
				              new Artikel2(3712, "Auslaufmodell", 15.36),
				              new Artikel2(3727, "AlterHut", 2.50),
				              new Artikel2(3710, "Bestseller", 35.60),
				              new Artikel2(3752, "BadSeller", 45.10),
				              new Artikel2(3777, "Garantiefall", 55.60),
				              new Artikel2(3709, "NeuesteMode", 105.00),
				              new Artikel2(3742, "BestesSt�ck", 500.00),
		                    };
		Arrays.sort(aListe);
		
		for (Artikel2 einArtikel2 : aListe)
		{
			System.out.println(einArtikel2);
		}
	}

}
