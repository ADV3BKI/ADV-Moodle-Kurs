/**
 * Bruch.java
 * 14.01.2019
 */
package oopBruchRechnen;

/**
 * @author stk
 * Kurzbeschreibung: Die Klasse Bruch dient zum Verarbeiten von Br�chen
 */
public class Bruch
{
    private int zaehler;
    private int nenner;

    // Standard Konstruktor
    public Bruch()
    {
        this.zaehler = 0;
        this.nenner = 1;
    }
    
    // �berladener Konstruktor
    public Bruch(int einZaehler, int einNenner)
    {
        this.zaehler = einZaehler;	// Initialwert setzen
        if (einNenner != 0)
        {
            this.nenner = einNenner;
        }
        else
        {   
            System.out.println("Fehler: Nenner darf nicht 0 sein");
        }
    }

    private static int berechneGGT(int a, int b)
    {
        int rest;

        if (a < 0) a = -a; // Algorithmus funktioniert nur f�r positive Zahlen
        if (b < 0) b = -b; // der ggT ist unabh�ngig vom Vorzeichen

        while (a % b != 0)
        {
            rest = b % a;
            b = a;
            a = rest;
        }
        return b; // b enth�lt den ggT
    }
    
    public void setiZaehler(int zaehler)
    {
        this.zaehler = zaehler; // Setze den Z�hler des aktuellen 
                                // Objektes auf den Wert des Parameters
    }
    
    public int getiZaehler()
    {
        return this.zaehler;
    }

    public void setiNenner(int nenner)
    {
        if (nenner != 0)
        {
            this.nenner = nenner; // Setze den Nenner des aktuellen 
                                  // Objektes auf den Wert des Parameters                
        }
        else
            System.out.println("Fehler: Nenner darf nicht 0 sein");
    }

    public int getiNenner()
    {
        return this.nenner;
    }

    public Bruch kuerzen()
    {
        Bruch erg = new Bruch();
        int ggt = berechneGGT(this.zaehler, this.nenner);

        erg.zaehler = this.zaehler / ggt;
        erg.nenner = this.nenner / ggt;

        return erg;
    }

    public Bruch addiereDazu(Bruch b2)
    {
        Bruch erg = new Bruch();

        erg.zaehler = this.zaehler * b2.nenner + b2.zaehler * this.nenner;
        erg.nenner = this.nenner * b2.nenner;

        erg = erg.kuerzen();

        return erg;
    }

    public Bruch subtrahiereDavon(Bruch b2)
    {
        Bruch erg = new Bruch();

        erg.zaehler = this.zaehler * b2.nenner - b2.zaehler * this.nenner;
        erg.nenner = this.nenner * b2.nenner;

        erg = erg.kuerzen();

        return erg;
    }

    public Bruch multipliziereMit(Bruch b2)
    {
        Bruch erg = new Bruch();

        erg.zaehler = this.zaehler * b2.zaehler;
        erg.nenner = this.nenner * b2.nenner;

        erg = erg.kuerzen();

        return erg;
    }

    public Bruch dividiereDurch(Bruch b2)
    {
        Bruch erg = new Bruch();

        erg.zaehler = this.zaehler * b2.nenner;
        erg.nenner = b2.zaehler * this.nenner;

        erg = erg.kuerzen();

        return erg;
    }

    public double ToDezimalZahl()
    {
        return (double)this.zaehler / this.nenner;
    }

    public String toString()
    {
        Bruch temp = this.kuerzen();
        String erg;

        if (temp.zaehler % temp.nenner == 0)
            erg = String.format("%d", temp.zaehler / temp.nenner);
        else
            if (temp.zaehler > temp.nenner)
                erg = String.format("%d %d/%d", temp.zaehler / temp.nenner,
                		            temp.zaehler % temp.nenner, temp.nenner);
            else
                erg = String.format("%d/%d", temp.zaehler, temp.nenner);


        return erg;
    }
}
