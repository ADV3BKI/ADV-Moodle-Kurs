/**
 * Artikel.java
 * 01.01.2019
 */
package collections;

/**
 * @author stk Kurzbeschreibung: Verwaltet die Daten eines Artikels
 *                               Erweiterte Version v2
 */
public class Artikel
{
	// Anfang Attribute
	private int iArtikelNr;
	private String sBezeichnung;
	private String sArtikelgruppe;
	private double dVerkaufsPreis;
	private double dLagerbestand;
	private double dMindestbestand;
	private double dMittlEinstPreis;
	// Klassenattribute
	private static double dMehrwertsteuersatz = 0.19;
	private static int iAnzahlErzeugterObjekte = 0;
	// Ende Attribute

	// Klassenmethoden
	public static double getdMehrwertsteuersatz()
	{
		return dMehrwertsteuersatz;
	}

	public static void setdMehrwertsteuersatz(double dMehrwertsteuersatz)
	{
		Artikel.dMehrwertsteuersatz = dMehrwertsteuersatz;
	}

	public static int getiAnzahlErzeugterObjekte()
	{
		return iAnzahlErzeugterObjekte;
	}

	public static void setiAnzahlErzeugterObjekte(int iAnzahlErzeugterObjekte)
	{
		Artikel.iAnzahlErzeugterObjekte = iAnzahlErzeugterObjekte;
	}

	// Konstruktoren
	public Artikel()
	{
		this.sBezeichnung = "-leer-";
		this.iArtikelNr = 0;
		this.dLagerbestand = 0;
		this.dMindestbestand = 0;
		this.dMittlEinstPreis = 0.0;
		this.dVerkaufsPreis = 0.0;
		Artikel.iAnzahlErzeugterObjekte++;
	}

	public Artikel(int iArtikelNr, String sBez, double dVerkaufsPreis)
	{
		this.iArtikelNr = iArtikelNr;
		this.sBezeichnung = sBez;
		this.dVerkaufsPreis = dVerkaufsPreis;
		Artikel.iAnzahlErzeugterObjekte++;
	}


	// Anfang Objektmethoden 
	public int getIArtikelNr()
	{
		return this.iArtikelNr;
	}

	public void setINr(int iNr)
	{
		this.iArtikelNr = iNr;
	}

	public String getSBezeichnung()
	{
		return this.sBezeichnung;
	}

	public void setSBezeichnung(String sBezeichnung)
	{
		this.sBezeichnung = sBezeichnung;
	}

	public double getDVerkaufsPreis()
	{
		return this.dVerkaufsPreis;
	}
	
	public double getDVerkaufsPreisBrutto()
	{
		return this.dVerkaufsPreis * (1 + dMehrwertsteuersatz);
	}
	
	

	public void setDVerkaufsPreis(double dVerkaufsPreis)
	{
		this.dVerkaufsPreis = dVerkaufsPreis;
	}

	public double getDLagerbestand()
	{
		return this.dLagerbestand;
	}

	public void setDLagerbestand(double dLagerbestand)
	{
		this.dLagerbestand = dLagerbestand;
	}

	public double getDMindestbestand()
	{
		return this.dMindestbestand;
	}

	public void setDMindestbestand(double dMindestbestand)
	{
		this.dMindestbestand = dMindestbestand;
	}

	public String getSArtikelgruppe()
	{
		return this.sArtikelgruppe;
	}

	public void setSArtikelgruppe(String sArtikelgruppe)
	{
		this.sArtikelgruppe = sArtikelgruppe;
	}

	public double getDMittlEinstPreis()
	{
		return this.dMittlEinstPreis;
	}

	public void setDMittlEinstPreis(double dMittlEinstPreis)
	{
		this.dMittlEinstPreis = dMittlEinstPreis;
	}

	public String toString()
	{
		return (iArtikelNr + "; " + sBezeichnung + "; " + sArtikelgruppe + "; " 
	            + dVerkaufsPreis +"; " + dMittlEinstPreis + "; " 
				+ dLagerbestand + "; " + dMindestbestand);
	}

	public void erh�hePreis(double dBetrag)
	{
		this.dVerkaufsPreis = this.dVerkaufsPreis + dBetrag;
	}

	public double ermittleGesamtLagerwert()
	{
		return ((int) ((this.dLagerbestand * this.dMittlEinstPreis) * 100)) / 100.0;
	}

	public boolean bestellen()
	{
		return ((dLagerbestand < dMindestbestand) ? true : false);
	}

	// Ende Methoden
}
