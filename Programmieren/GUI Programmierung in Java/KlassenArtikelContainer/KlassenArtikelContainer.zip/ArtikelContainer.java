package collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class ArtikelContainer
{
	private ArrayList<Artikel> alleArtikel;
	
	/**
	 * Konstruktor, erzeugt Array f�r max 20 Artikel (wird dynamisch verl�ngert)
	 */
	public ArtikelContainer()
	{
		//this.alleArtikel = new ArrayList<Artikel>(20);
		this(20);
	}

	/**
	 *
	 * Konstruktor, erzeugt Array f�r iAnzArtikel Artikel
	 * 
	 * @param iKapazitaet
	 *            L�nge des Start Arrays (wird dynamisch verl�ngert)
	 * 
	 */
	public ArtikelContainer(int iKapazitaet)
	{
		this.alleArtikel = new ArrayList<Artikel>(iKapazitaet);
	}

	/**
	 * @return liefert aktuelle Anzahl gespeicherter Artikel
	 */
	public int getIAnzAkt()
	{
		return this.alleArtikel.size();
	}

	/**
	 * neuerArtikel wird in Array gespeichert und die Anzahl aktualisiert
	 * 
	 * @param neuerArtikel
	 *            Verweis auf Artikelobjekt das gespeichert werden soll
	 * 
	 */
	public void speichereArtikel(Artikel neuerArtikel)
	{
		this.alleArtikel.add(neuerArtikel);
	}

	/**
	 * Sucht den Artikel der die gegebene iArtikelNr besitzt;
	 * Es wird davon ausgegangen, dass Artikelnummern eindeutig sind.
	 * 
	 * @param iArtikelNr
	 * Artikel mit dieser Nummer wird gesucht
	 * @return
	 * Ist der gesuchte Artikel vorhanden, so wird ein Verweis darauf zur�ckgegeben,
	 * null sonst.
	 * 
	 */
	public Artikel sucheArtikelNachNr(int iArtikelNr)
	{
		Artikel gesucht = null;
		Artikel aktuell;
//		Iterator<Artikel> it = alleArtikel.iterator(); // 3 P
//		
//		while (gesucht == null && it.hasNext()) // 2 P
//		{
//			aktuell = it.next();  // 1 P
//			if (aktuell.getINr() == iArtikelNr) // 2 P
//				gesucht = aktuell; // 1 P
//			
//		}
		int iInd = 0;

		while (iInd < this.alleArtikel.size() && this.alleArtikel.get(iInd).getIArtikelNr() != iArtikelNr)
		{
			iInd++;
		}
		
		if (iInd < this.alleArtikel.size()) // ArtikelNr wurde gefunden
		{
			gesucht = this.alleArtikel.get(iInd);
		}

		return gesucht; // null, wenn nicht gefunden // 1 P

	}

	/**
	 * sucht alle Artikel mit sBezeichnung == sSuchBezeichnung
	 * 
	 * @param sSuchBezeichnung
	 *            Artikel mit dieser Bezeichnung werden gesucht und zur�ckgegeben
	 * @return Artikel [] mit den gesuchten Artikeln; L�nge des Arrays = Anzahl
	 * der gefundenen Artikel; falls kein Artikel gefunden wird ist die R�ckgabe null
	 * 
	 * <br><br>Es wird davon ausgegangen, dass es mehrere Artikel mit der gleichen
	 * Bezeichnung geben kann. Deshalb soll ein Artikel Array zur�ckgegeben werden
	 * Das Array hat genau die L�nge der gefundenen Artikel. <br>
	 * Die gefundenen Artikel werden zun�chst in einer ArrayList gespeichert.
	 * Vor der R�ckgabe wird die LinkedList in ein Array konvertiert, das
	 * genau so lang ist, wie die Zahl der gefundenen Artikel
	 */
	public Artikel[] sucheArtikelNachBezeichnung(String sSuchBezeichnung)
	{
		ArrayList<Artikel> gefundeneArtikel = new ArrayList<>();

		for (Artikel einArtikel: this.alleArtikel)
		{
			if (einArtikel.getSBezeichnung().equals(sSuchBezeichnung))
			{
				gefundeneArtikel.add(einArtikel);
			}
		}
		return gefundeneArtikel.toArray(new Artikel[0]); // null, wenn nichts gefunden
	}
}
