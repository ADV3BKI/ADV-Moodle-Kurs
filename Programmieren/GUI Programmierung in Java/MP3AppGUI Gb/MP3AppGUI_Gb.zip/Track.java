/**
 * Track.java
 * 20.03.2019
 */
package mp3App;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class Track
{
    private String titel;
    private String interpret;
    private String pfad;

    public Track(String titel, String interpret, String pfad)
    {
        this.titel = titel;
        this.interpret = interpret;
        this.pfad = pfad;
    }

    public void setTitel(String titel)
    {
        this.titel = titel;
    }

    public String getTitel()
    {
        return this.titel;
    }

    public void setInterpret(String interpret)
    {
        this.interpret = interpret;
    }

    public String getInterpret()
    {
        return this.interpret;
    }

    public void setPfad(String pfad)
    {
        this.pfad = pfad;
    }

    public String getPfad()
    {
        return this.pfad;
    }
}
