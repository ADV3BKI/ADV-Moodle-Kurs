/**
 * SimplePlayer.java
 * 20.03.2019
 */
package mp3App;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;


/**
 * @author stk
 *
 *
 *         Kurzbeschreibung:
 */
public class SimplePlayer
{
	private Player meinPlayer;
	private boolean bIsPlaying = false;

	public void playTrack(Track einTrack) throws Exception
    {
		if (this.bIsPlaying)
		{
			this.meinPlayer.close();
			this.bIsPlaying = false;
		}
        try {
            FileInputStream fis     = new FileInputStream(einTrack.getPfad());
            BufferedInputStream bis = new BufferedInputStream(fis);
            this.meinPlayer = new Player(bis);
            this.bIsPlaying = true;
        }
        catch (Exception e) {
            throw(e);
        }

        // run in new thread to play in background
        try {
            new Thread() {
                public void run() {
                    try
					{
						meinPlayer.play();
					}
					catch (JavaLayerException e)
					{
						RuntimeException re = new RuntimeException();
						throw  re;
					}
                }
            }.start();
        }
        catch (Exception e) {
            throw(e);
        }
        
    }

	public void stopTrack()
	{
		if (this.bIsPlaying)
		{
			this.meinPlayer.close();
			this.bIsPlaying = false;
		}
	}

}
