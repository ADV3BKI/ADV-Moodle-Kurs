/**
 * MP3AppGUI_Gb.java
 * 20.03.2019
 */
package mp3App;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * @author stk
 *
 *
 * Kurzbeschreibung:
 */
public class MP3AppGUI_Gb
{

	private JFrame frmMyMusicplayer;
	private JTextField txtTitel;
	private JTextField txtInterpret;
	private Track einTrack = new Track("8081", "Pat Methene",
			                    "Dateien\\04 - 8081.mp3");
	private SimplePlayer einfacherPlayer = new SimplePlayer();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					MP3AppGUI_Gb window = new MP3AppGUI_Gb();
					window.frmMyMusicplayer.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MP3AppGUI_Gb()
	{
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize()
	{

		frmMyMusicplayer = new JFrame();
		frmMyMusicplayer.setTitle("My MusicPlayer");
		frmMyMusicplayer.setBounds(100, 100, 450, 200);
		frmMyMusicplayer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel pnlCenter = new JPanel();
		frmMyMusicplayer.getContentPane().add(pnlCenter, BorderLayout.CENTER);
		pnlCenter.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel pnlTitel = new JPanel();
		pnlTitel.setBorder(new EmptyBorder(10, 20, 20, 20));
		pnlCenter.add(pnlTitel);
		pnlTitel.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel lblTitel = new JLabel("Titel");
		lblTitel.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		pnlTitel.add(lblTitel);
		
		txtTitel = new JTextField();
		txtTitel.setHorizontalAlignment(SwingConstants.CENTER);
		txtTitel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTitel.setLabelFor(txtTitel);
		txtTitel.setText(einTrack.getTitel());
		pnlTitel.add(txtTitel);
		txtTitel.setColumns(100);
		
		JLabel lblInterpret = new JLabel("Interpret");
		lblInterpret.setHorizontalAlignment(SwingConstants.CENTER);
		lblInterpret.setFont(new Font("Tahoma", Font.PLAIN, 14));
		pnlTitel.add(lblInterpret);
		
		txtInterpret = new JTextField();
		lblInterpret.setLabelFor(txtInterpret);
		txtInterpret.setHorizontalAlignment(SwingConstants.CENTER);
		txtInterpret.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtInterpret.setColumns(100);
		txtInterpret.setText(einTrack.getInterpret());
		pnlTitel.add(txtInterpret);
		
		JPanel pnlButtons = new JPanel();
		frmMyMusicplayer.getContentPane().add(pnlButtons, BorderLayout.SOUTH);
	
		JButton btnPlay = new JButton("Play");
		btnPlay.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					einfacherPlayer.playTrack(einTrack);
				}
				catch (Exception ex)
				{
					JOptionPane.showMessageDialog(frmMyMusicplayer,
							                    "mp3 Datei nicht gefunden!");
				}
			}
		});
		btnPlay.setFont(new Font("Tahoma", Font.PLAIN, 14));
		pnlButtons.add(btnPlay);
		
		JButton btnStop = new JButton("Stop");
		btnStop.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				einfacherPlayer.stopTrack();
			}
		});
		pnlButtons.add(btnStop);
	}

}
