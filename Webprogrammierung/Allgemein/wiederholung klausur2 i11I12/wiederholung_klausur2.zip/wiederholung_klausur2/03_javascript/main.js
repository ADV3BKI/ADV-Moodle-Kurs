console.log("Hallo Welt");
let y = 15;
let x = 8;
console.log(x+y);