<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berechnung der Bildgröße</title>
</head>
<body>
    <h1>Ergebnis der Berechnung</h1>

    <?php
    //Man kann die etwas komisch aussehenden POST-Variablen auch in einfache Variablen reinschreiben
    $width = $_POST["width"];
    $resolution = $_POST["res"];

    $bildbreite = ($width / $resolution)*2.54;
    // 1 inch sind 2,54 cm
    //runden?


    //Ausgabe

    echo "<p>Bei einer Breite des Bildes von $width px und einer gewünschten Auflösung von $resolution dpi ergibt sich eine Bildbreite von $bildbreite cm</p>";


    ?>
    
</body>
</html>