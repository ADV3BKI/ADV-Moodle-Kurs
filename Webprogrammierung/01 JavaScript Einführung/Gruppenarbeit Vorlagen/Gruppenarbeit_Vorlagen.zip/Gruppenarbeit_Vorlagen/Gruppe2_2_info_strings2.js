"use strict"

// Newline
console.log('Hallo \nWelt!')

// String wiederholen
console.log("-".repeat(20))

// .slice(start, end)
console.log("Hallo Welt".slice(6, 8))


//Alternative substring, ähnlich wie slice, aber auch rückwärts möglich

console.log("Hallo Welt".substring(6,8))

//substring ist auch rückwärts möglich
console.log("Hallo Welt".substring(8,6))
