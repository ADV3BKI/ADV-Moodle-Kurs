"use strict"

let shopping = "Apfel, Banane, Pfirsich"

console.log(shopping.split(", "))


let shoppingList = ['Apfel', 'Banane', 'Pfirsich']

console.log(shoppingList.join(", "))

//Überprüfen Sie den Typ jeweils vor und nach der Umwandlung mit typeof