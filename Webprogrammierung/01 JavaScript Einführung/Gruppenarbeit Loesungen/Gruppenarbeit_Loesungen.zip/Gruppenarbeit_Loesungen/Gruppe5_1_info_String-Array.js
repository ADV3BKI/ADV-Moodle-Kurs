"use strict"

let shopping = "Apfel, Banane, Pfirsich"
console.log("shopping is type of"+ typeof shopping)
console.log(shopping)
console.log(shopping.split(", "))
console.log("shopping is type of"+ typeof shopping)
console.log("aber shopping.split ist typeof" + typeof shopping.split(", "))
console.log(shopping)


let shoppingList = ['Apfel', 'Banane', 'Pfirsich']

console.log(shoppingList.join(", "))

//Überprüfen Sie den Typ jeweils vor und nach der Umwandlung mit typeof